import { e as escape_html, b as ensure_array_like, a as attr, d as stringify } from "../../../../chunks/index2.js";
import "clsx";
import { query, collection, orderBy, onSnapshot, deleteDoc, doc, updateDoc, serverTimestamp, addDoc } from "firebase/firestore";
import { d as db } from "../../../../chunks/index3.js";
const DEFAULT_ICON = "📦";
const COLLECTION = "products";
function createProductsStore() {
  let list = [];
  const q = query(collection(db, COLLECTION), orderBy("name"));
  onSnapshot(q, (snap) => {
    list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
  });
  return {
    get list() {
      return list;
    },
    // Add a new product.
    // `stock` defaults to 0; `createdAt` is set by the server.
    // `pricingMode` defaults to 'fixed'; `trackStock` defaults to true.
    // Optional fields (unitLabel, depositAmount, discountAmount) are only written
    // if present — Firestore documents should not store undefined fields.
    async add(data) {
      const doc_data = {
        name: data.name,
        price: data.price,
        pricingMode: data.pricingMode ?? "fixed",
        iconEmoji: data.iconEmoji ?? DEFAULT_ICON,
        trackStock: data.trackStock ?? true,
        stock: 0,
        createdAt: serverTimestamp()
      };
      if (data.unitLabel) doc_data.unitLabel = data.unitLabel;
      if (data.depositAmount) doc_data.depositAmount = data.depositAmount;
      if (data.discountAmount) doc_data.discountAmount = data.discountAmount;
      await addDoc(collection(db, COLLECTION), doc_data);
    },
    // Update only the fields that changed.
    // `id`, `stock`, and `createdAt` are never updated through this path —
    // stock changes go through the Sales (Sprint 2) and Inventory (Sprint 5) flows.
    async update(id, data) {
      await updateDoc(doc(db, COLLECTION, id), data);
    },
    // Hard delete — no soft delete in v1.
    async remove(id) {
      await deleteDoc(doc(db, COLLECTION, id));
    }
  };
}
const products = createProductsStore();
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    function priceDisplay(p) {
      const amount = p.price % 1 === 0 ? `₱${p.price}` : `₱${p.price.toFixed(2)}`;
      if (p.pricingMode === "per_unit") {
        return `${amount}/${p.unitLabel || "pc"}`;
      }
      return p.unitLabel ? `${amount} / ${p.unitLabel}` : amount;
    }
    function badges(p) {
      const b = [];
      if (p.depositAmount) b.push(`+₱${p.depositAmount} deposit`);
      if (p.discountAmount) b.push(`-₱${p.discountAmount} disc.`);
      if (!p.trackStock) b.push("stock untracked");
      return b;
    }
    $$renderer2.push(`<div class="flex h-full flex-col"><header class="flex items-center justify-between border-b border-gray-100 px-4 py-4"><h1 class="text-lg font-bold text-gray-900">Products</h1> <span class="text-sm text-gray-400">${escape_html(products.list.length)} items</span></header> <div class="flex-1 overflow-y-auto">`);
    if (products.list.length === 0) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="flex flex-col items-center justify-center gap-3 px-8 py-24 text-center"><span class="text-5xl">📦</span> <p class="text-base font-medium text-gray-700">No products yet</p> <p class="text-sm text-gray-400">Tap the <strong>+</strong> button below to add your first product.</p></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<ul><!--[-->`);
      const each_array = ensure_array_like(products.list);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let product = each_array[$$index];
        $$renderer2.push(`<li class="flex items-center gap-3 border-b border-gray-100 px-4 py-3"><span class="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-xl bg-gray-100 text-2xl">${escape_html(product.iconEmoji)}</span> <button class="min-w-0 flex-1 text-left"><p class="truncate text-sm font-semibold text-gray-900">${escape_html(product.name)}</p> <p class="text-sm text-green-700 font-medium">${escape_html(priceDisplay(product))}</p> `);
        if (badges(product).length > 0) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<p class="mt-0.5 text-xs text-gray-400">${escape_html(badges(product).join(" · "))}</p>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></button> <button class="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg text-gray-300 active:text-red-400"${attr("aria-label", `Delete ${stringify(product.name)}`)}><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="h-5 w-5"><path fill-rule="evenodd" d="M8.75 1A2.75 2.75 0 006 3.75v.443c-.795.077-1.584.176-2.365.298a.75.75 0 10.23 1.482l.149-.022.841 10.518A2.75 2.75 0 007.596 19h4.807a2.75 2.75 0 002.742-2.53l.841-10.52.149.023a.75.75 0 00.23-1.482A41.03 41.03 0 0014 4.193V3.75A2.75 2.75 0 0011.25 1h-2.5zM10 4c.84 0 1.673.025 2.5.075V3.75c0-.69-.56-1.25-1.25-1.25h-2.5c-.69 0-1.25.56-1.25 1.25v.325C8.327 4.025 9.16 4 10 4zM8.58 7.72a.75.75 0 00-1.5.06l.3 7.5a.75.75 0 101.5-.06l-.3-7.5zm4.34.06a.75.75 0 10-1.5-.06l-.3 7.5a.75.75 0 101.5.06l.3-7.5z" clip-rule="evenodd"></path></svg></button></li>`);
      }
      $$renderer2.push(`<!--]--></ul>`);
    }
    $$renderer2.push(`<!--]--></div> <button class="absolute bottom-20 right-4 flex h-14 w-14 items-center justify-center rounded-full bg-green-600 text-white shadow-lg text-2xl active:bg-green-700" aria-label="Add product">+</button></div> `);
    {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
  });
}
export {
  _page as default
};
