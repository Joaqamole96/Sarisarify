import { g as getContext, b as ensure_array_like, a as attr, c as attr_class, d as stringify, f as store_get, e as escape_html, u as unsubscribe_stores } from "../../../chunks/index2.js";
import "clsx";
import "@sveltejs/kit/internal";
import "../../../chunks/exports.js";
import "../../../chunks/utils.js";
import "@sveltejs/kit/internal/server";
import "../../../chunks/root.js";
import "../../../chunks/state.svelte.js";
const getStores = () => {
  const stores$1 = getContext("__svelte__");
  return {
    /** @type {typeof page} */
    page: {
      subscribe: stores$1.page.subscribe
    },
    /** @type {typeof navigating} */
    navigating: {
      subscribe: stores$1.navigating.subscribe
    },
    /** @type {typeof updated} */
    updated: stores$1.updated
  };
};
const page = {
  subscribe(fn) {
    const store = getStores().page;
    return store.subscribe(fn);
  }
};
function _layout($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let { children } = $$props;
    const tabs = [
      { href: "/sales", label: "Sales", icon: "🛒" },
      { href: "/products", label: "Products", icon: "📦" },
      { href: "/borrows", label: "Borrows", icon: "📋" },
      { href: "/stats", label: "Stats", icon: "📊" },
      { href: "/inventory", label: "Stock", icon: "🗄️" }
    ];
    $$renderer2.push(`<div class="flex h-screen flex-col"><main class="flex-1 overflow-y-auto">`);
    children($$renderer2);
    $$renderer2.push(`<!----></main> <nav class="flex border-t border-gray-200 bg-white"><!--[-->`);
    const each_array = ensure_array_like(tabs);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let tab = each_array[$$index];
      $$renderer2.push(`<a${attr("href", tab.href)}${attr_class(`flex flex-1 flex-col items-center gap-0.5 py-2 text-xs ${stringify(store_get($$store_subs ??= {}, "$page", page).url.pathname.startsWith(tab.href) ? "text-green-600 font-semibold" : "text-gray-500")}`)}><span class="text-xl">${escape_html(tab.icon)}</span> <span>${escape_html(tab.label)}</span></a>`);
    }
    $$renderer2.push(`<!--]--></nav></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
export {
  _layout as default
};
