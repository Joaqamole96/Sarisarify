import { h as head, a as attr, e as escape_html } from "../../chunks/index2.js";
import "clsx";
import { a as auth } from "../../chunks/index3.js";
import { onAuthStateChanged } from "firebase/auth";
function createAuthState() {
  let user = null;
  let ready = false;
  onAuthStateChanged(auth, (firebaseUser) => {
    user = firebaseUser;
    ready = true;
  });
  return {
    get user() {
      return user;
    },
    get ready() {
      return ready;
    }
  };
}
const authState = createAuthState();
function _layout($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { children } = $$props;
    let email = "";
    let password = "";
    let loading = false;
    head("12qhfyh", $$renderer2, ($$renderer3) => {
      $$renderer3.push(`<link rel="manifest" href="/manifest.webmanifest"/>`);
    });
    if (!authState.ready) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="flex h-screen items-center justify-center bg-green-50"><p class="text-green-700 text-lg font-medium">Loading…</p></div>`);
    } else if (!authState.user) {
      $$renderer2.push("<!--[1-->");
      $$renderer2.push(`<div class="flex h-screen flex-col items-center justify-center gap-6 bg-green-50 px-8"><h1 class="text-3xl font-bold text-green-800">Sarisarify</h1> <div class="w-full max-w-sm flex flex-col gap-3"><input type="email" placeholder="Email"${attr("value", email)} class="rounded-xl border border-green-200 px-4 py-3 text-base outline-none focus:border-green-500"/> <input type="password" placeholder="Password"${attr("value", password)} class="rounded-xl border border-green-200 px-4 py-3 text-base outline-none focus:border-green-500"/> `);
      {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> <button${attr("disabled", loading, true)} class="rounded-xl bg-green-600 py-3 text-base font-semibold text-white active:bg-green-700 disabled:opacity-50">${escape_html("Sign in")}</button></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
      children($$renderer2);
      $$renderer2.push(`<!---->`);
    }
    $$renderer2.push(`<!--]-->`);
  });
}
export {
  _layout as default
};
