export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["icon-192.png","icon-512.png","manifest.webmanifest","sw.js"]),
	mimeTypes: {".png":"image/png",".webmanifest":"application/manifest+json",".js":"text/javascript"},
	_: {
		client: {start:"_app/immutable/entry/start.DZixllRK.js",app:"_app/immutable/entry/app.D5q444l0.js",imports:["_app/immutable/entry/start.DZixllRK.js","_app/immutable/chunks/BFWteG0j.js","_app/immutable/chunks/BuBotuPq.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/BdHW5pnp.js","_app/immutable/chunks/BUApaBEI.js","_app/immutable/chunks/DU6xrNzC.js","_app/immutable/entry/app.D5q444l0.js","_app/immutable/chunks/BuBotuPq.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/CqPJxaqs.js","_app/immutable/chunks/Bzak7iHL.js","_app/immutable/chunks/DU6xrNzC.js","_app/immutable/chunks/Khe60Wzh.js","_app/immutable/chunks/CXE3t7Y7.js","_app/immutable/chunks/BHZCWRa3.js","_app/immutable/chunks/BdHW5pnp.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/3.js')),
			__memo(() => import('./nodes/4.js')),
			__memo(() => import('./nodes/5.js')),
			__memo(() => import('./nodes/6.js')),
			__memo(() => import('./nodes/7.js')),
			__memo(() => import('./nodes/8.js'))
		],
		remotes: {
			
		},
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			},
			{
				id: "/(app)/borrows",
				pattern: /^\/borrows\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/(app)/inventory",
				pattern: /^\/inventory\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/(app)/products",
				pattern: /^\/products\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/(app)/sales",
				pattern: /^\/sales\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/(app)/stats",
				pattern: /^\/stats\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 8 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
