import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { initializeFirestore, persistentLocalCache } from "firebase/firestore";
const firebaseConfig = {
  apiKey: "AIzaSyA1vnp0H4JNK5u1jA4TnP44OWDn0EQ3ltM",
  authDomain: "sarisarify-8b925.firebaseapp.com",
  projectId: "sarisarify-8b925",
  storageBucket: "sarisarify-8b925.firebasestorage.app",
  messagingSenderId: "264633423483",
  appId: "1:264633423483:web:6a96d050ffa1d8a64c74de"
};
const app = initializeApp(firebaseConfig);
const db = initializeFirestore(app, {
  localCache: persistentLocalCache()
});
const auth = getAuth(app);
export {
  auth as a,
  db as d
};
