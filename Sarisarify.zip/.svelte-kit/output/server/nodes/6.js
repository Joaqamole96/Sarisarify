

export const index = 6;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/(app)/products/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/6.BH399sjd.js","_app/immutable/chunks/Bzak7iHL.js","_app/immutable/chunks/BuBotuPq.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/CqPJxaqs.js","_app/immutable/chunks/Khe60Wzh.js","_app/immutable/chunks/CXE3t7Y7.js","_app/immutable/chunks/CsUY5miJ.js","_app/immutable/chunks/Dh4HeFxY.js","_app/immutable/chunks/C0leZMJA.js"];
export const stylesheets = [];
export const fonts = [];
