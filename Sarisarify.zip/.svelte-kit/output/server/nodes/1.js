

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.BC-4bVvk.js","_app/immutable/chunks/Bzak7iHL.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/BuBotuPq.js","_app/immutable/chunks/CqPJxaqs.js","_app/immutable/chunks/BFWteG0j.js","_app/immutable/chunks/BdHW5pnp.js","_app/immutable/chunks/BUApaBEI.js","_app/immutable/chunks/DU6xrNzC.js"];
export const stylesheets = [];
export const fonts = [];
