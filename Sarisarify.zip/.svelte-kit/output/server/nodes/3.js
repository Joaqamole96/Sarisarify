import * as universal from '../entries/pages/_page.ts.js';

export const index = 3;
export { universal };
export const universal_id = "src/routes/+page.ts";
export const imports = ["_app/immutable/nodes/3.TTt4NHv-.js","_app/immutable/chunks/BUApaBEI.js"];
export const stylesheets = [];
export const fonts = [];
