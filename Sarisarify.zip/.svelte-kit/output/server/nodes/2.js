

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/(app)/_layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.G8R4Cfrb.js","_app/immutable/chunks/Bzak7iHL.js","_app/immutable/chunks/BuBotuPq.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/CqPJxaqs.js","_app/immutable/chunks/BZ6SucGP.js","_app/immutable/chunks/CXE3t7Y7.js","_app/immutable/chunks/CsUY5miJ.js","_app/immutable/chunks/Dh4HeFxY.js","_app/immutable/chunks/BHZCWRa3.js","_app/immutable/chunks/BdHW5pnp.js","_app/immutable/chunks/BFWteG0j.js","_app/immutable/chunks/BUApaBEI.js","_app/immutable/chunks/DU6xrNzC.js"];
export const stylesheets = [];
export const fonts = [];
